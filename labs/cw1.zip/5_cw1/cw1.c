#include <stdio.h>
#include <math.h>

const double PI = 3.141592653; // declare PI and initialize it with 3.1415926... 

// write plot function below. 
// two inputs, a and b.
// no output. 

void main(){
    // you can directly use trignometric functions and the constant PI
    printf("%f\n",sin(PI/2)); 
    // test your plot functions with different a and b. 
    // plot(2, PI/2);
}