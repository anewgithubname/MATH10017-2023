#include <stdio.h>
void main(){
    int a[3] = {2,3,4}; int *pa = &a[0];

    printf("%d\n", a[2]);
    printf("%d\n", *(pa+2));
    printf("%d\n", *(a+2));
    //prints out, 4, 4, 4. 


    // TODO: write a for loop, printing out contents in a, using the array indexing notation a[i]. 

    // TODO: write a for loop, printing out contents in a, WITHOUT using the array indexing notation a[i]. 
    // How many ways can you perform the task? Hint: find at least 2 solutions
}